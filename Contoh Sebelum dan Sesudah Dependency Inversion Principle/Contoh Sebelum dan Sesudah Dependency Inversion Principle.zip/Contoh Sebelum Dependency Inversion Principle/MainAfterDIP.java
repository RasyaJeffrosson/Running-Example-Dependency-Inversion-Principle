public class MainAfterDIP {
}
